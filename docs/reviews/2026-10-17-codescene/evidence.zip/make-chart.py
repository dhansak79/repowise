from pathlib import Path
import json,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/repowise-analysis-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
e=json.loads((p/'mcp-evidence.json').read_text())
labels={'update':'CLI update command','persist':'Analysis persistence','dead_code':'Dead-code analyser','parser':'Source parser','init':'CLI initialisation','incremental':'Incremental pipeline','health_engine':'Health engine','scoring':'Health scoring','mcp_search':'MCP search','graph_ui':'Web graph wrapper','health_ranking':'Health ranking','health_registry':'Detector registry','health_grading':'Health grading','call_resolver':'Call resolver','update_persistence':'CLI update persistence','context_targets':'MCP context targets','orchestrator':'Pipeline orchestration','shared_graph_ui':'Shared graph component','persistence_models':'Persistence models'}
rows=sorted([(labels[k],r['data']['score']) for k,r in e['reviews'].items()],key=lambda r:r[1])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
fig,ax=plt.subplots(figsize=(12,10.5));fig.patch.set_facecolor('#ffffff');ax.set_facecolor('#ffffff')
colors=['#c54443' if s<4 else '#c89632' if s<9 else '#298267' for _,s in rows]
ax.barh(range(len(rows)),[s for _,s in rows],color=colors,height=.64)
ax.set_yticks(range(len(rows)),[n for n,_ in rows]);ax.invert_yaxis();ax.set_xlim(0,10.65)
for i,(_,s) in enumerate(rows):ax.text(s+.10,i,f'{s:.2f}',va='center',fontsize=10,color='#253341')
ax.axvline(4,color='#c54443',alpha=.45,linestyle='--',linewidth=1)
ax.axvline(9,color='#298267',alpha=.45,linestyle='--',linewidth=1)
ax.set_xticks(range(0,11));ax.set_xlabel('Local CodeScene Code Health (higher is better)',labelpad=12)
ax.grid(axis='x',color='#e9edf0',linewidth=.7);ax.set_axisbelow(True);ax.tick_params(axis='y',length=0,pad=12)
for s in ['top','right','left']:ax.spines[s].set_visible(False)
ax.spines['bottom'].set_color('#bac4cb')
fig.suptitle('RepoWise: targeted CodeScene assessment',x=.055,y=.965,ha='left',fontsize=20,fontweight='bold',color='#183148')
fig.text(.055,.925,'19 first-party files · selected from hotspots and adjacent product paths, plus healthy comparisons',fontsize=10.3,color='#52606d')
fig.text(.055,.900,'Risk-directed sample: these proportions do not describe the whole repository.',fontsize=10.3,color='#52606d')
fig.text(.055,.035,'Analysed 17 October 2026 · source revision c9bbf7d4e2e · raw MCP evidence included',fontsize=9.5,color='#52606d')
fig.subplots_adjust(left=.285,right=.94,top=.865,bottom=.11)
fig.savefig(p/'code-health-sample.png',dpi=180,facecolor='white')
fig.savefig(p/'code-health-sample.svg',facecolor='white')
print('Chart written')
