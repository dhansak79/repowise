#!/usr/bin/env python3
"""Reproduce read-only source measurements for the pinned RepoWise assessment.

Run against a clean checkout at the revision below. This script executes git
read operations and parses source with ast; it does not import RepoWise,
install dependencies, run application code, or modify the checkout.
"""
from __future__ import annotations
import argparse
import ast
import collections
import json
import re
import subprocess
from pathlib import Path

REVISION = 'c9bbf7d4e2ed3f352bc4da0d6a5fdce561179819'
PATHS = {
 'update':'packages/cli/src/repowise/cli/commands/update_cmd/command.py',
 'persist':'packages/core/src/repowise/core/pipeline/persist.py',
 'dead_code':'packages/core/src/repowise/core/analysis/dead_code/analyzer.py',
 'parser':'packages/core/src/repowise/core/ingestion/parser.py',
 'init':'packages/cli/src/repowise/cli/commands/init_cmd/command.py',
 'incremental':'packages/core/src/repowise/core/pipeline/incremental.py',
 'update_persistence':'packages/cli/src/repowise/cli/commands/update_cmd/persistence.py',
 'context_targets':'packages/server/src/repowise/server/mcp_server/tool_context/targets.py',
 'orchestrator':'packages/core/src/repowise/core/pipeline/orchestrator.py',
 'mcp_search':'packages/server/src/repowise/server/mcp_server/tool_search.py',
}
WINDOWS = {
 'last_30_days':('2026-09-17T00:00:00Z','2026-10-17T23:59:59Z'),
 'last_90_days':('2026-07-19T00:00:00Z','2026-10-17T23:59:59Z'),
}

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--repo',type=Path,required=True)
 ap.add_argument('--out',type=Path,required=True)
 args=ap.parse_args();root=args.repo.resolve();out=args.out.resolve()
 def git(*argv):
  return subprocess.check_output(['git',*argv],cwd=root,text=True)
 assert git('rev-parse','HEAD').strip()==REVISION,'Use a checkout at '+REVISION
 assert not git('status','--porcelain').strip(),'Use a clean checkout'
 assert not out.is_relative_to(root),'Write output outside the source checkout'
 out.mkdir(parents=True,exist_ok=True)
 def save(name,obj):
  (out/name).write_text(json.dumps(obj,indent=2)+'\n')
 allfiles=[p for p in git('ls-files','-z').split('\0') if p]
 source={};logs={};all_functions=[]
 for label,path in PATHS.items():
  text=(root/path).read_text();tree=ast.parse(text)
  funcs=[{'name':n.name,'line':n.lineno,'end':n.end_lineno,
    'physical_span':n.end_lineno-n.lineno+1,
    'parameters':len(n.args.posonlyargs)+len(n.args.args)+len(n.args.kwonlyargs)
       +int(n.args.vararg is not None)+int(n.args.kwarg is not None)}
    for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
  d={'path':path,'physical_lines':len(text.splitlines()),'functions':len(funcs),
     'largest_functions':sorted(funcs,key=lambda f:-f['physical_span'])[:4]}
  for window,(start,end) in WINDOWS.items():
   log=git('log','--no-merges','--since='+start,'--until='+end,
           '--format=%H\t%cs\t%s','--',path).splitlines()
   fixes=[s for s in log if s.split('\t',2)[-1].lower().startswith(('fix:','fix('))]
   d[window]={'nonmerge_commits_touching_path':len(log),
     'fix_prefix_commits_touching_path':len(fixes),
     'recent_fix_subjects':[s.split('\t',2)[-1] for s in fixes[:6]]}
   if window=='last_30_days':logs[label]=log
  source[label]=d
 save('repowise-source-hotspot-crosschecks.json',source)
 sets={k:{s.split('\t')[0] for s in log} for k,log in logs.items()}
 core=['update','persist','dead_code','parser'];union=set().union(*(sets[k] for k in core))
 fixes={s.split('\t')[0] for k in core for s in logs[k]
        if s.split('\t',2)[-1].lower().startswith(('fix:','fix('))}
 co={'window':'2026-09-17 through pinned HEAD 2026-10-16 (UTC)',
  'unique_nonmerge_commits_touching_any_priority_target':len(union),
  'unique_fix_prefix_commits_touching_any_priority_target':len(fixes),
  'update_cochanges':[{'other':k,'shared_commits':len(sets['update']&sets[k]),
   'update_commits':len(sets['update']),
   'fraction_of_update_commits':len(sets['update']&sets[k])/len(sets['update'])}
   for k in ['update_persistence','init','incremental','persist','parser','dead_code']]}
 save('repowise-git-cochange-crosschecks.json',co)
 exts={'.py','.ts','.tsx','.js','.jsx','.rs','.go'}
 marker=re.compile(r'(?im)^\s*(?://|#|/\*|\*|<!--)?\s*(?:@generated\b|auto[- ]?generated\b|generated (?:by|from)\b|this file (?:is|was) (?:auto[- ]?)?generated\b)')
 kept=[];excluded=[];broad=[]
 for path in allfiles:
  if not path.startswith('packages/') or Path(path).suffix not in exts:continue
  parts=set(Path(path).parts)
  recognized_test=parts & {'test','tests','__tests__'} or path.endswith(('.test.ts','.test.tsx','.spec.ts','.spec.tsx'))
  try:text=(root/path).read_text()
  except (OSError,UnicodeDecodeError):continue
  if not recognized_test:
   broad.append({'path':path,'physical_lines':len(text.splitlines()),'suffix':Path(path).suffix})
   if path.endswith('.py'):
    try:tree=ast.parse(text)
    except SyntaxError:tree=None
    if tree:
     for n in ast.walk(tree):
      if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
       all_functions.append({'path':path,'name':n.name,'start':n.lineno,'end':n.end_lineno,
        'physical_span':n.end_lineno-n.lineno+1,
        'parameters':len(n.args.posonlyargs)+len(n.args.args)+len(n.args.kwonlyargs)
          +int(n.args.vararg is not None)+int(n.args.kwarg is not None)})
  if parts & {'node_modules','.venv','venv','vendor','vendors','vendored','third_party',
      'third-party','thirdparty','dist','build','__pycache__','fixtures','test','tests','__tests__'} or recognized_test:
   excluded.append({'path':path,'reason':'tests, fixtures, dependencies, vendor or build directory'});continue
  if '/src/' not in path:
   excluded.append({'path':path,'reason':'outside package src tree (tooling/config)'});continue
  if 'generated' in parts or marker.search('\n'.join(text.splitlines()[:30])):
   excluded.append({'path':path,'reason':'generated directory or explicit generated header',
                    'physical_lines':len(text.splitlines())});continue
  kept.append({'path':path,'physical_lines':len(text.splitlines()),'package':path.split('/')[1]})
 scope={'criteria':'Tracked source files under packages/*/src; recognized tests/fixtures/dependencies/vendor/build directories and generated paths/headers excluded. Directory/header heuristic, not a provenance audit of every line.',
  'included_files':len(kept),'included_physical_lines':sum(r['physical_lines'] for r in kept),
  'by_package':dict(collections.Counter(r['package'] for r in kept)),
  'generated_exclusions':[r for r in excluded if r['reason'].startswith('generated')],
  'other_excluded_file_count':sum(not r['reason'].startswith('generated') for r in excluded),
  'files':kept,'exclusions':excluded}
 save('first-party-scope.json',scope);save('repowise-python-functions.json',all_functions)
 print(json.dumps({'revision':REVISION,'priority_target_commits':len(union),
  'fix_prefix_commits':len(fixes),'scoped_source_files':len(kept),
  'scoped_physical_lines':scope['included_physical_lines']},indent=2))

if __name__=='__main__':main()
